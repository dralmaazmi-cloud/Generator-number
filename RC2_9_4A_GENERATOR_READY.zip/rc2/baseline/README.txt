rc2/baseline — earlier releases, as production source, for matched-seed comparison.

rc293/  RC2.9.3, the release this candidate is measured against
rc292/  RC2.9.2, the diversity baseline RC2.9.3 itself refined

Each directory holds that release's PRODUCTION bundle exactly as its freeze
record attests it: src/, app.js, index.html, report.js, practice-journey.js,
performance-model.js, generator_manifest.json, package.json — nothing else.
SHA256SUMS lists every file's hash and FREEZE.json is the release's own freeze.
Node needs no dependencies to run the engine, so a baseline is directly usable:

  # one seed, both engines, explanations side by side
  node -e "import('./src/index.js').then(async m=>{const E=m.default;\
    const q=new E().generateQuestion({seed:'cmp-1',difficulty:'medium'});\
    console.log(q.question);console.log(q.explanation);\
    console.log(JSON.stringify(q.option_rationales??q.distractor_rationales,null,1));})"

  # and the same command with  cd rc2/baseline/rc293  in front of it

The seeds are the only thing that has to match: both engines draw the same
question for the same seed (rc2/RC294_ZERO_DIFF.json records that over 10,000
seeds for the Phase-A checkpoint), so any difference the reviewer sees is a
difference in the TEXT, which is what the RC2.9.3 review could not check.
