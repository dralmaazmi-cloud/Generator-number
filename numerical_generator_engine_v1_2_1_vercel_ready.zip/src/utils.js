export const LETTERS = ['A','B','C','D','E','F'];

export const DIFFICULTY_LABELS = {
  easy: 'سهل',
  medium: 'متوسط',
  hard: 'صعب'
};

export function gcd(a,b) {
  a = Math.abs(a); b = Math.abs(b);
  while (b) [a,b] = [b, a % b];
  return a || 1;
}

export function lcm(a,b) {
  return Math.abs(a*b) / gcd(a,b);
}

export function roundTo(n, decimals = 6) {
  const p = 10 ** decimals;
  return Math.round((n + Number.EPSILON) * p) / p;
}

export function isNearlyInteger(n, eps = 1e-9) {
  return Math.abs(n - Math.round(n)) < eps;
}

export function formatNumber(n, maxDecimals = 2) {
  if (typeof n === 'string') return n;
  if (!Number.isFinite(n)) return String(n);
  if (isNearlyInteger(n)) return String(Math.round(n));
  return roundTo(n, maxDecimals).toFixed(maxDecimals).replace(/0+$/,'').replace(/\.$/,'');
}

export function percentOf(value, pct) {
  return value * pct / 100;
}

export function canonical(v) {
  if (typeof v === 'number') return `n:${roundTo(v,8)}`;
  return `s:${String(v).trim()}`;
}

export function uniqByCanonical(values) {
  const seen = new Set();
  const out = [];
  for (const v of values) {
    const key = canonical(v);
    if (!seen.has(key)) {
      seen.add(key);
      out.push(v);
    }
  }
  return out;
}

export function chooseCleanDivisorPair(rng, products = [24,30,36,40,42,48,54,56,60,63,64,72,80,84,90,96,100,108,120]) {
  const product = rng.pick(products);
  const divisors = [];
  for (let d=2; d<=12; d++) if (product % d === 0) divisors.push(d);
  const a = rng.pick(divisors);
  return [a, product/a, product];
}

export function makeOptionSet({
  correct,
  distractors,
  rng,
  format = v => String(v),
  preferredCorrectLetter = null,
  rationaleByValue = new Map(),
  genericRationale = 'ناتج عن مسار حسابي غير صحيح أو خطوة ناقصة.'
}) {
  const clean = [];
  const correctFormatted = format(correct);
  const seenFormatted = new Set([correctFormatted]);
  const addDistractor = (raw, rationale = null) => {
    const formatted = format(raw);
    if (formatted === correctFormatted || seenFormatted.has(formatted)) return false;
    seenFormatted.add(formatted);
    clean.push({value: raw, rationale: rationale || genericRationale});
    return true;
  };
  for (const d of distractors) {
    const raw = (d && typeof d === 'object' && 'value' in d) ? d.value : d;
    const rationale = (d && typeof d === 'object' && 'rationale' in d) ? d.rationale : null;
    const key = canonical(raw);
    addDistractor(raw, rationale || rationaleByValue.get(key) || genericRationale);
  }
  // Safety filler: family generators should normally supply 5+ meaningful distractors,
  // but deterministic nearby alternatives prevent a generation failure when two
  // independently-derived mistakes collapse to the same formatted value.
  if (clean.length < 5 && typeof correct === 'number' && Number.isFinite(correct)) {
    const baseStep = Math.abs(correct) < 2 ? 0.5 : Math.abs(correct) < 10 ? 1 : Math.abs(correct) < 50 ? 2 : Math.abs(correct) < 200 ? 5 : 10;
    const candidates = [
      correct + baseStep, correct - baseStep,
      correct + 2*baseStep, correct - 2*baseStep,
      correct + 3*baseStep, correct - 3*baseStep,
      correct * 2, correct / 2,
      correct + 5*baseStep, correct - 5*baseStep
    ];
    for (const c of candidates) {
      if (clean.length >= 5) break;
      if (!Number.isFinite(c)) continue;
      if (correct > 0 && c <= 0) continue;
      addDistractor(c, 'قيمة قريبة ناتجة عن خطأ حسابي أو خطوة ناقصة.');
    }
  }
  if (clean.length < 5) throw new Error(`Need at least 5 unique distractors; got ${clean.length}`);
  const picked = rng.sample(clean, 5);
  const correctLetter = preferredCorrectLetter && LETTERS.includes(preferredCorrectLetter)
    ? preferredCorrectLetter
    : rng.pick(LETTERS);
  const wrongLetters = LETTERS.filter(x => x !== correctLetter);
  const shuffledWrong = rng.shuffle(picked);
  const options = {};
  const distractorAnalysis = {};
  let wi = 0;
  for (const letter of LETTERS) {
    if (letter === correctLetter) {
      options[letter] = format(correct);
      distractorAnalysis[letter] = 'الإجابة الصحيحة.';
    } else {
      const item = shuffledWrong[wi++];
      options[letter] = format(item.value);
      distractorAnalysis[letter] = item.rationale;
    }
  }
  return {
    options,
    correct_option: correctLetter,
    correct_value: format(correct),
    distractor_analysis: distractorAnalysis
  };
}

export function finalizeQuestion(base, rng, preferredCorrectLetter = null) {
  const optionSet = makeOptionSet({
    correct: base.correct,
    distractors: base.distractors,
    rng,
    format: base.format || (v => String(v)),
    preferredCorrectLetter,
    genericRationale: base.genericDistractorRationale
  });

  const q = {
    id: base.id,
    generator_id: base.generator_id,
    seed: base.seed,
    family: base.family,
    family_ar: base.family_ar,
    category: base.category,
    subskill: base.subskill,
    difficulty: base.difficulty,
    difficulty_ar: DIFFICULTY_LABELS[base.difficulty],
    question: base.question,
    display_expression: base.display_expression ?? null,
    options: optionSet.options,
    correct_option: optionSet.correct_option,
    correct_value: optionSet.correct_value,
    explanation: {
      how_to_start: base.explanation.how_to_start,
      steps: base.explanation.steps,
      answer: base.explanation.answer || `الإجابة الصحيحة: ${optionSet.correct_value}.`,
      fast_method: base.explanation.fast_method || null,
      remember: base.explanation.remember,
      distractor_analysis: optionSet.distractor_analysis
    },
    metadata: {
      generated: true,
      engine_version: base.engine_version || '1.0.0',
      template_id: base.template_id,
      parameters: base.parameters || {},
      estimated_steps: base.estimated_steps ?? null,
      concept_tags: base.concept_tags || [],
      ...base.metadata
    }
  };
  return q;
}

export function validateQuestion(q) {
  const errors = [];
  if (!q || typeof q !== 'object') return {valid:false, errors:['Question is not an object']};
  const letters = Object.keys(q.options || {});
  if (letters.length !== 6 || LETTERS.some(l => !(l in q.options))) errors.push('options_must_have_A_to_F');
  const vals = LETTERS.map(l => q.options?.[l]);
  if (new Set(vals).size !== 6) errors.push('options_must_be_unique');
  if (!LETTERS.includes(q.correct_option)) errors.push('invalid_correct_option');
  if (q.options?.[q.correct_option] !== q.correct_value) errors.push('correct_value_mismatch');
  if (vals.filter(v => v === q.correct_value).length !== 1) errors.push('correct_value_not_unique');
  if (!q.question?.trim()) errors.push('missing_question');
  if (!q.explanation?.how_to_start) errors.push('missing_how_to_start');
  if (!Array.isArray(q.explanation?.steps) || !q.explanation.steps.length) errors.push('missing_steps');
  if (!q.explanation?.remember) errors.push('missing_remember');
  if (!['easy','medium','hard'].includes(q.difficulty)) errors.push('invalid_difficulty');
  return {valid: errors.length === 0, errors};
}

export function questionSignature(q) {
  return `${q.family}|${q.generator_id}|${q.question}|${q.display_expression || ''}`;
}

export function buildBalancedLetterSchedule(count, rng) {
  const base = [];
  for (let i=0; i<count; i++) base.push(LETTERS[i % LETTERS.length]);
  return rng.shuffle(base);
}

export function arabicJoin(items) {
  if (items.length <= 1) return items[0] || '';
  if (items.length === 2) return `${items[0]} و${items[1]}`;
  return `${items.slice(0,-1).join('، ')}، و${items.at(-1)}`;
}

export function dayShift(dayIndex, delta) {
  return ((dayIndex + delta) % 7 + 7) % 7;
}

export const DAYS_AR = ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];

export function divisorsOf(n, min=1, max=n) {
  const arr=[];
  for(let i=Math.max(1,min); i<=Math.min(max,n); i++) if(n%i===0) arr.push(i);
  return arr;
}

export function makeId(prefix, seed) {
  const safe = String(seed).replace(/[^a-zA-Z0-9_-]/g,'').slice(-18) || 'seed';
  return `${prefix}-${safe}`;
}
