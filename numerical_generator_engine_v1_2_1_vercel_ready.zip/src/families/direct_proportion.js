import {makeId, formatNumber} from '../utils.js';

export function generateDirectProportion({difficulty,rng,seed,engineVersion}){
  const ctx={difficulty,rng,seed,engineVersion,family:'direct_proportion',family_ar:'التناسب المباشر',category:'التناسب المباشر البسيط'};
  const list=difficulty==='easy'?[unitItems,unitCost]
    :difficulty==='medium'?[recipeScale,mapScale,fractionalUnit]
    :[compoundScale,multiUnitCost];
  return rng.pick(list)(ctx);
}

function unitItems(ctx){
  const {rng}=ctx; const boxes=rng.pick([3,4,5,6]), per=rng.pick([6,8,10,12]); const total=boxes*per, newBoxes=rng.pick([5,7,8,9,10]); const correct=newBoxes*per;
  return base(ctx,'PROP_E_ITEMS','معدل ثابت بين عدد وحدات وكمية','easy',`إذا كانت ${boxes} صناديق متماثلة تحتوي على ${total} قطعة، فكم قطعة تحتوي عليها ${newBoxes} صناديق بالمعدل نفسه؟`,correct,[total,newBoxes*boxes,per,correct+per,Math.max(per,correct-per),total+newBoxes],v=>`${formatNumber(v)} قطعة`,[
    `الصندوق الواحد = ${total} ÷ ${boxes} = ${per} قطع.`,
    `${newBoxes} صناديق = ${newBoxes} × ${per} = ${correct} قطعة.`
  ],'احسب قيمة الوحدة الواحدة أولًا.','في التناسب المباشر، قيمة الوحدة هي أسرع طريق للحل.',`${total} ÷ ${boxes} ثم × ${newBoxes}.`,2);
}

function unitCost(ctx){
  const {rng}=ctx; const n=rng.pick([3,4,5,6]), unit=rng.pick([5,6,7,8,10,12]), total=n*unit, newN=rng.pick([7,8,9,10,12]); const correct=newN*unit;
  return base(ctx,'PROP_E_COST','تكلفة عدد أكبر من وحدات متطابقة','easy',`إذا كانت ${n} وحدات تكلف ${total} درهمًا، فكم تكلف ${newN} وحدات بالسعر نفسه؟`,correct,[total,unit,newN*n,correct+unit,Math.max(unit,correct-unit),total+newN],v=>`${formatNumber(v)} درهمًا`,[
    `سعر الوحدة = ${total} ÷ ${n} = ${unit} دراهم.`,
    `${newN} وحدات تكلف ${newN} × ${unit} = ${correct} درهمًا.`
  ],'اعرف سعر الوحدة ثم اضرب في العدد المطلوب.','التناسب المباشر يعني أن السعر يتغير بنفس نسبة العدد.','السعر لكل وحدة × عدد الوحدات.',2);
}

function recipeScale(ctx){
  const {rng}=ctx; const pieces=rng.pick([8,10,12,15]), cups=rng.pick([2,3,4,5]); const factor=rng.pick([1.5,2,2.5]); const target=pieces*factor, correct=cups*factor; if(!Number.isInteger(target)||!Number.isFinite(correct)) return recipeScale(ctx);
  return base(ctx,'PROP_M_RECIPE','تكبير وصفة بنسبة ثابتة','medium',`تحتاج وصفة إلى ${cups} أكواب من الدقيق لصنع ${pieces} قطعة. كم كوبًا تحتاج لصنع ${target} قطعة بالمعدل نفسه؟`,correct,[cups,target/pieces,cups+factor,correct+1,Math.max(.5,correct-1),target/cups],v=>`${formatNumber(v)} كوب`,[
    `عامل التكبير = ${target} ÷ ${pieces} = ${formatNumber(factor)}.`,
    `الدقيق المطلوب = ${cups} × ${formatNumber(factor)} = ${formatNumber(correct)} كوب.`
  ],'احسب كم مرة كبر عدد القطع.','في التناسب المباشر، الكمية المقابلة تتغير بعامل التكبير نفسه.','اضرب الكمية الأصلية في عامل التكبير.',3);
}

function mapScale(ctx){
  const {rng}=ctx; const cmBase=rng.pick([1,2,4]), kmBase=rng.pick([5,10,20]); const perCm=kmBase/cmBase; const a=rng.pick([4.2,5.4,6.5,7.2,8.4]), b=rng.pick([1.2,1.5,1.8,2.4]); const total=a+b; const correct=total*perCm; if(!Number.isInteger(correct)) return mapScale(ctx);
  return base(ctx,'PROP_M_MAP','مقياس خريطة مع جمع مرحلتين','medium',`على خريطة، كل ${cmBase} سم تمثل ${kmBase} كم. طول مسار ${formatNumber(a)} سم، ثم أضيف إليه طريق جانبي طوله ${formatNumber(b)} سم على الخريطة. ما المسافة الحقيقية للمسار كاملًا؟`,correct,[a*perCm,b*perCm,total*kmBase,(a+b)/perCm,correct+5,Math.max(5,correct-5)],v=>`${formatNumber(v)} كم`,[
    `الطول على الخريطة = ${formatNumber(a)} + ${formatNumber(b)} = ${formatNumber(total)} سم.`,
    `كل 1 سم يمثل ${formatNumber(perCm)} كم.`,
    `${formatNumber(total)} × ${formatNumber(perCm)} = ${correct} كم.`
  ],'اجمع أطوال الخريطة أولًا ثم طبّق المقياس.','وحّد المسار المطلوب قبل التحويل من الخريطة للحقيقة.','إجمالي السنتيمترات × كيلومترات لكل سنتيمتر.',3);
}

function fractionalUnit(ctx){
  const {rng}=ctx; const n=rng.pick([4,5,8,10]), total=rng.pick([1,2,2.5,4,5]); const unit=total/n; const newN=rng.pick([12,15,20,24]); const correct=unit*newN; if(!Number.isFinite(correct)||Math.abs(correct*4-Math.round(correct*4))>1e-9) return fractionalUnit(ctx);
  return base(ctx,'PROP_M_FRAC_UNIT','قيمة وحدة كسرية ثم التوسع','medium',`إذا كان وزن ${n} عناصر متماثلة ${formatNumber(total)} كجم، فما وزن ${newN} عنصرًا من النوع نفسه؟`,correct,[total,unit,newN/total,correct+total,Math.max(.25,correct-total),newN*total],v=>`${formatNumber(v)} كجم`,[
    `وزن العنصر الواحد = ${formatNumber(total)} ÷ ${n} = ${formatNumber(unit)} كجم.`,
    `وزن ${newN} عنصرًا = ${newN} × ${formatNumber(unit)} = ${formatNumber(correct)} كجم.`
  ],'لا تخف من قيمة الوحدة الكسرية؛ احسبها ثم اضرب.','قيمة الوحدة قد تكون كسرًا بسيطًا وما زال التناسب مباشرًا.','الوزن للوحدة × العدد المطلوب.',3);
}

function compoundScale(ctx){
  const {rng}=ctx; const units=rng.pick([4,5,6]), amount=rng.pick([20,25,30,36,40]), targetUnits=rng.pick([8,9,10,12]); const extraPct=rng.pick([10,20,25]); const base=amount/units*targetUnits; const correct=base*(1+extraPct/100); if(!Number.isInteger(correct)) return compoundScale(ctx);
  return baseQ(ctx,'PROP_H_COMPOUND','تناسب مباشر ثم زيادة إضافية','hard',`تحتاج ${units} وحدات إلى ${amount} كجم من مادة. نريد تجهيز ${targetUnits} وحدات، مع إضافة احتياط بنسبة ${extraPct}% فوق الكمية المحسوبة. كم كجم نحتاج؟`,correct,[base,amount*(1+extraPct/100),amount/units,correct+5,Math.max(1,correct-5),base+extraPct],v=>`${formatNumber(v)} كجم`,[
    `المادة لكل وحدة = ${amount} ÷ ${units} = ${formatNumber(amount/units)} كجم.`,
    `لـ${targetUnits} وحدات نحتاج ${formatNumber(base)} كجم قبل الاحتياط.`,
    `مع احتياط ${extraPct}%: ${formatNumber(base)} × ${1+extraPct/100} = ${formatNumber(correct)} كجم.`
  ],'حل التناسب أولًا ثم طبّق الزيادة الإضافية.','لا تطبق الاحتياط على الكمية الأصلية إذا كان عدد الوحدات تغير.','قيمة الوحدة → الكمية الجديدة → الاحتياط.',4);
}

function multiUnitCost(ctx){
  const {rng}=ctx; const packN=rng.pick([3,4,5]), packCost=rng.pick([18,20,24,25,30]), target=rng.pick([9,10,12,15]); const unit=packCost/packN; const delivery=rng.pick([5,10,15]); const correct=unit*target+delivery; if(!Number.isInteger(correct)) return multiUnitCost(ctx);
  return baseQ(ctx,'PROP_H_COST_PLUS','تكلفة وحدات مع رسم ثابت','hard',`تكلف ${packN} وحدات ${packCost} درهمًا بالسعر نفسه. إذا اشترينا ${target} وحدة وأضيف رسم ثابت قدره ${delivery} دراهم، فما التكلفة الكلية؟`,correct,[unit*target,packCost*target/packN+delivery*target,packCost+delivery,target*unit-delivery,correct+unit,Math.max(1,correct-unit)],v=>`${formatNumber(v)} درهمًا`,[
    `سعر الوحدة = ${packCost} ÷ ${packN} = ${formatNumber(unit)}.`,
    `سعر ${target} وحدة = ${formatNumber(unit*target)}.`,
    `نضيف الرسم الثابت مرة واحدة: ${formatNumber(unit*target)} + ${delivery} = ${formatNumber(correct)}.`
  ],'افصل التكلفة المتناسبة عن الرسم الثابت.','الرسم الثابت لا يتكرر مع كل وحدة ما لم يذكر السؤال ذلك.','سعر الوحدات + الرسم الثابت.',4);
}

function base(ctx,...args){return baseQ(ctx,...args)}
function baseQ(ctx,template_id,subskill,difficulty,question,correct,distractors,format,steps,how,remember,fast,estimated_steps){
 return {id:makeId(template_id,ctx.seed),generator_id:template_id,template_id,seed:ctx.seed,family:ctx.family,family_ar:ctx.family_ar,category:ctx.category,subskill,difficulty,question,display_expression:null,correct,distractors:distractors.filter(v=>Number.isFinite(v)&&v>0).map(v=>({value:v,rationale:'خطأ في قيمة الوحدة أو عامل التكبير أو إضافة مبلغ/نسبة في المرحلة الخطأ.'})),format,explanation:{how_to_start:how,steps,answer:`الإجابة الصحيحة: ${format(correct)}.`,fast_method:fast,remember},estimated_steps,concept_tags:['direct-proportion','unit-value'],engine_version:ctx.engineVersion};
}
