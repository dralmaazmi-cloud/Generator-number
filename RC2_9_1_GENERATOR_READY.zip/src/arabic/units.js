// Section 12: one central lexicon and one formatter for Arabic number/unit
// agreement. Templates must never concatenate a number and a unit themselves;
// tools/check-manual-units.mjs enforces that as a build gate.

/**
 * Each unit declares the four forms Arabic needs:
 *   singular  — used for 1 (written with واحد/واحدة, no numeral)
 *   dual      — used for 2 (no numeral); `dualOblique` after a preposition
 *   plural    — جمع القلة, used for 3..10 with the numeral
 *   accSing   — المفرد المنصوب (تمييز), used for 11+, 0 and fractional counts
 */
/**
 * RC2.3-4. Units that count indivisible things.
 *
 * The distinction is about the WORLD, not about grammar: half a worker and two
 * thirds of a machine do not exist, while 1.5 hours, 2.5 km and 7.25 dirhams all
 * do. It matters because a wrong option that is not a whole number, next to a
 * question asking how many workers, is one a candidate can strike out without
 * doing any of the reasoning — 10.4% of published options were in that position
 * before this list existed.
 *
 * `cup` is deliberately absent: a recipe really can call for a cup and a half.
 */
const COUNT_UNITS = new Set(['worker', 'machine', 'unit', 'piece', 'box', 'task', 'person', 'item', 'word',
  // RC2.7-3. The scenario layer counts concrete things as well as abstract
  // ones. Each of these is indivisible in the world for the same reason a
  // worker is: half a seedling, two thirds of a loaf and 1.4 seats do not
  // exist. `meter`, `degree` and `point` are deliberately absent — those
  // really do take fractions.
  'page', 'can', 'bottle', 'loaf', 'seat', 'seedling', 'shirt', 'book',
  'card', 'order', 'visitor', 'student', 'panel', 'trip', 'device', 'tree', 'value']);

export const isCountUnit = unitId => COUNT_UNITS.has(unitId);

export const UNITS = Object.freeze({
  day:     {singular:'يوم',      one:'يوم واحد',      dual:'يومان',      dualOblique:'يومين',      plural:'أيام',      accSing:'يومًا'},
  hour:    {singular:'ساعة',     one:'ساعة واحدة',    dual:'ساعتان',     dualOblique:'ساعتين',     plural:'ساعات',     accSing:'ساعة'},
  minute:  {singular:'دقيقة',    one:'دقيقة واحدة',   dual:'دقيقتان',    dualOblique:'دقيقتين',    plural:'دقائق',     accSing:'دقيقة'},
  year:    {singular:'سنة',      one:'سنة واحدة',     dual:'سنتان',      dualOblique:'سنتين',      plural:'سنوات',     accSing:'سنة'},
  worker:  {singular:'عامل',     one:'عامل واحد',     dual:'عاملان',     dualOblique:'عاملين',     plural:'عمال',      accSing:'عاملًا'},
  machine: {singular:'آلة',      one:'آلة واحدة',     dual:'آلتان',      dualOblique:'آلتين',      plural:'آلات',      accSing:'آلة'},
  unit:    {singular:'وحدة',     one:'وحدة واحدة',    dual:'وحدتان',     dualOblique:'وحدتين',     plural:'وحدات',     accSing:'وحدة'},
  piece:   {singular:'قطعة',     one:'قطعة واحدة',    dual:'قطعتان',     dualOblique:'قطعتين',     plural:'قطع',       accSing:'قطعة'},
  dirham:  {singular:'درهم',     one:'درهم واحد',     dual:'درهمان',     dualOblique:'درهمين',     plural:'دراهم',     accSing:'درهمًا'},
  cup:     {singular:'كوب',      one:'كوب واحد',      dual:'كوبان',      dualOblique:'كوبين',      plural:'أكواب',     accSing:'كوبًا'},
  box:     {singular:'صندوق',    one:'صندوق واحد',    dual:'صندوقان',    dualOblique:'صندوقين',    plural:'صناديق',    accSing:'صندوقًا'},
  task:    {singular:'مهمة',     one:'مهمة واحدة',    dual:'مهمتان',     dualOblique:'مهمتين',     plural:'مهام',      accSing:'مهمة'},
  part:    {singular:'جزء',      one:'جزء واحد',      dual:'جزءان',      dualOblique:'جزأين',      plural:'أجزاء',     accSing:'جزءًا'},
  km:      {singular:'كيلومتر',  one:'كيلومتر واحد',  dual:'كيلومتران',  dualOblique:'كيلومترين',  plural:'كيلومترات', accSing:'كيلومترًا'},
  liter:   {singular:'لتر',      one:'لتر واحد',      dual:'لتران',      dualOblique:'لترين',      plural:'لترات',     accSing:'لترًا'},
  kg:      {singular:'كيلوجرام', one:'كيلوجرام واحد', dual:'كيلوجرامان', dualOblique:'كيلوجرامين', plural:'كيلوجرامات',accSing:'كيلوجرامًا'},
  word:    {singular:'كلمة',     one:'كلمة واحدة',    dual:'كلمتان',     dualOblique:'كلمتين',     plural:'كلمات',     accSing:'كلمة'},
  person:  {singular:'شخص',      one:'شخص واحد',      dual:'شخصان',      dualOblique:'شخصين',      plural:'أشخاص',     accSing:'شخصًا'},
  item:    {singular:'عنصر',     one:'عنصر واحد',     dual:'عنصران',     dualOblique:'عنصرين',     plural:'عناصر',     accSing:'عنصرًا'},
  cm:      {singular:'سنتيمتر',  one:'سنتيمتر واحد',  dual:'سنتيمتران',  dualOblique:'سنتيمترين',  plural:'سنتيمترات', accSing:'سنتيمترًا'},
  week:    {singular:'أسبوع',    one:'أسبوع واحد',    dual:'أسبوعان',    dualOblique:'أسبوعين',    plural:'أسابيع',    accSing:'أسبوعًا'},
  // RC2.6: partnership questions are stated in months.
  month:   {singular:'شهر',      one:'شهر واحد',      dual:'شهران',      dualOblique:'شهرين',      plural:'أشهر',      accSing:'شهرًا'},
  // RC2.7-3. The scenario layer. Each entry declares the same four forms the
  // lexicon has always required, so a composed stem inflects exactly as a
  // hand-written one does; nothing here is a synonym of an existing unit, each
  // is a different thing to count.
  page:    {singular:'صفحة',     one:'صفحة واحدة',    dual:'صفحتان',     dualOblique:'صفحتين',     plural:'صفحات',     accSing:'صفحة'},
  can:     {singular:'علبة',     one:'علبة واحدة',    dual:'علبتان',     dualOblique:'علبتين',     plural:'علب',       accSing:'علبة'},
  bottle:  {singular:'زجاجة',    one:'زجاجة واحدة',   dual:'زجاجتان',    dualOblique:'زجاجتين',    plural:'زجاجات',    accSing:'زجاجة'},
  loaf:    {singular:'رغيف',     one:'رغيف واحد',     dual:'رغيفان',     dualOblique:'رغيفين',     plural:'أرغفة',     accSing:'رغيفًا'},
  seat:    {singular:'مقعد',     one:'مقعد واحد',     dual:'مقعدان',     dualOblique:'مقعدين',     plural:'مقاعد',     accSing:'مقعدًا'},
  seedling:{singular:'شتلة',     one:'شتلة واحدة',    dual:'شتلتان',     dualOblique:'شتلتين',     plural:'شتلات',     accSing:'شتلة'},
  shirt:   {singular:'قميص',     one:'قميص واحد',     dual:'قميصان',     dualOblique:'قميصين',     plural:'قمصان',     accSing:'قميصًا'},
  book:    {singular:'كتاب',     one:'كتاب واحد',     dual:'كتابان',     dualOblique:'كتابين',     plural:'كتب',       accSing:'كتابًا'},
  card:    {singular:'بطاقة',    one:'بطاقة واحدة',   dual:'بطاقتان',    dualOblique:'بطاقتين',    plural:'بطاقات',    accSing:'بطاقة'},
  order:   {singular:'طلب',      one:'طلب واحد',      dual:'طلبان',      dualOblique:'طلبين',      plural:'طلبات',     accSing:'طلبًا'},
  visitor: {singular:'زائر',     one:'زائر واحد',     dual:'زائران',     dualOblique:'زائرين',     plural:'زوار',      accSing:'زائرًا'},
  student: {singular:'طالب',     one:'طالب واحد',     dual:'طالبان',     dualOblique:'طالبين',     plural:'طلاب',      accSing:'طالبًا'},
  panel:   {singular:'لوح',      one:'لوح واحد',      dual:'لوحان',      dualOblique:'لوحين',      plural:'ألواح',     accSing:'لوحًا'},
  trip:    {singular:'رحلة',     one:'رحلة واحدة',    dual:'رحلتان',     dualOblique:'رحلتين',     plural:'رحلات',     accSing:'رحلة'},
  device:  {singular:'جهاز',     one:'جهاز واحد',     dual:'جهازان',     dualOblique:'جهازين',     plural:'أجهزة',     accSing:'جهازًا'},
  tree:    {singular:'شجرة',     one:'شجرة واحدة',    dual:'شجرتان',     dualOblique:'شجرتين',     plural:'أشجار',     accSing:'شجرة'},
  meter:   {singular:'متر',      one:'متر واحد',      dual:'متران',      dualOblique:'مترين',      plural:'أمتار',     accSing:'مترًا'},
  degree:  {singular:'درجة',     one:'درجة واحدة',    dual:'درجتان',     dualOblique:'درجتين',     plural:'درجات',     accSing:'درجة'},
  point:   {singular:'نقطة',     one:'نقطة واحدة',    dual:'نقطتان',     dualOblique:'نقطتين',     plural:'نقاط',      accSing:'نقطة'},
  // The abstract member of a list. Already emitted by the averages family as
  // a hand-written «قيم»; declaring it here is what lets the composer inflect
  // it instead of spelling one form out.
  value:   {singular:'قيمة',     one:'قيمة واحدة',    dual:'قيمتان',     dualOblique:'قيمتين',     plural:'قيم',       accSing:'قيمة'}
});

/** Units that never inflect: symbols, rates and percentages. */
export const INVARIANT_UNITS = Object.freeze({
  kmPerHour: 'كم/ساعة',
  unitPerHour: 'وحدة/ساعة',
  unitPerMinute: 'وحدة/دقيقة',
  piecePerHour: 'قطعة/ساعة',
  kmPerLiter: 'كم/لتر',
  wordPerMinute: 'كلمة/دقيقة',
  // RC2.7-3. Rate symbols for the scenario layer.
  pagePerHour: 'صفحة/ساعة',
  pagePerMinute: 'صفحة/دقيقة',
  canPerHour: 'علبة/ساعة',
  bottlePerHour: 'زجاجة/ساعة',
  loafPerHour: 'رغيف/ساعة',
  seedlingPerHour: 'شتلة/ساعة',
  shirtPerHour: 'قميص/ساعة',
  panelPerHour: 'لوح/ساعة',
  orderPerHour: 'طلب/ساعة',
  bookPerHour: 'كتاب/ساعة',
  cardPerMinute: 'بطاقة/دقيقة',
  literPerMinute: 'لتر/دقيقة',
  literPerHour: 'لتر/ساعة',
  piecePerMinute: 'قطعة/دقيقة',
  loafPerMinute: 'رغيف/دقيقة',
  bottlePerMinute: 'زجاجة/دقيقة',
  shirtPerMinute: 'قميص/دقيقة',
  canPerMinute: 'علبة/دقيقة',
  panelPerMinute: 'لوح/دقيقة',
  loafPerHourAlt: 'رغيف/ساعة',
  percent: '%',
  none: ''
});

/**
 * RC2.9.1. Which rate symbols have a COUNTED NOUN on top.
 *
 * «كم/ساعة» is an abbreviation over a time word and never inflects. «زجاجة/ساعة»
 * is a noun over a time word, and a noun after a number agrees with it: the
 * engine published «5 زجاجة/ساعة», «4 صفحة/ساعة» and «6 قميص/ساعة», each of
 * which reads to an Arabic speaker as a number with the wrong plural on it.
 *
 * The slash stays. It keeps an option compact, it is what the stem/option unit
 * check reads, and «5 زجاجات/ساعة» is how this is written in Arabic technical
 * prose. Only the noun moves.
 */
export const RATE_NUMERATOR = Object.freeze({
  unitPerHour: ['unit', 'ساعة'], unitPerMinute: ['unit', 'دقيقة'],
  piecePerHour: ['piece', 'ساعة'], piecePerMinute: ['piece', 'دقيقة'],
  pagePerHour: ['page', 'ساعة'], pagePerMinute: ['page', 'دقيقة'],
  canPerHour: ['can', 'ساعة'], canPerMinute: ['can', 'دقيقة'],
  bottlePerHour: ['bottle', 'ساعة'], bottlePerMinute: ['bottle', 'دقيقة'],
  loafPerHour: ['loaf', 'ساعة'], loafPerMinute: ['loaf', 'دقيقة'],
  loafPerHourAlt: ['loaf', 'ساعة'],
  shirtPerHour: ['shirt', 'ساعة'], shirtPerMinute: ['shirt', 'دقيقة'],
  panelPerHour: ['panel', 'ساعة'], panelPerMinute: ['panel', 'دقيقة'],
  seedlingPerHour: ['seedling', 'ساعة'],
  orderPerHour: ['order', 'ساعة'],
  bookPerHour: ['book', 'ساعة'],
  cardPerMinute: ['card', 'دقيقة'],
  literPerHour: ['liter', 'ساعة'], literPerMinute: ['liter', 'دقيقة'],
  wordPerMinute: ['word', 'دقيقة']
  // kmPerHour and kmPerLiter are deliberately absent: «كم» is an abbreviation,
  // not a counted noun, and «5 كيلومترات/ساعة» is not how a speed is written.
});

/** Short aliases so templates can say `km` or `كم` interchangeably. */
export const UNIT_ALIASES = Object.freeze({
  days:'day', hours:'hour', minutes:'minute', years:'year', workers:'worker',
  machines:'machine', units:'unit', pieces:'piece', dirhams:'dirham', cups:'cup',
  boxes:'box', tasks:'task', parts:'part', kilometers:'km', liters:'liter',
  kilograms:'kg', words:'word', persons:'person', people:'person', items:'item',
  centimeters:'cm', weeks:'week', months:'month',
  pages:'page', cans:'can', bottles:'bottle', loaves:'loaf', seats:'seat',
  seedlings:'seedling', shirts:'shirt', books:'book', cards:'card',
  orders:'order', visitors:'visitor', students:'student', panels:'panel',
  trips:'trip', devices:'device', trees:'tree', meters:'meter',
  degrees:'degree', points:'point', values:'value'
});

export function resolveUnitId(unitId) {
  if (!unitId) return null;
  if (UNITS[unitId]) return unitId;
  if (UNIT_ALIASES[unitId] && UNITS[UNIT_ALIASES[unitId]]) return UNIT_ALIASES[unitId];
  return null;
}

/** Decimal rendering for counts. Display-only rounding, never fed back in. */
export function displayNumber(n, maxDecimals = 6) {
  if (typeof n === 'string') return n;
  if (!Number.isFinite(n)) return String(n);
  if (Number.isInteger(n)) return String(n);
  const rounded = Number(n.toFixed(maxDecimals));
  return String(rounded);
}

/**
 * Section 12-A. The single place where a count and a unit meet.
 *
 * @param {number} n            the count
 * @param {string} unitId       key of UNITS / INVARIANT_UNITS (or an alias)
 * @param {'nominative'|'oblique'} grammaticalContext
 *        'oblique' is the منصوب/مجرور position, e.g. straight after خلال / بعد / من.
 */
export function formatNumberWithUnit(n, unitId, grammaticalContext = 'nominative') {
  if (unitId in INVARIANT_UNITS) {
    const rate = RATE_NUMERATOR[unitId];
    if (rate) {
      const [countId, per] = rate;
      const u = UNITS[countId];
      const num = Number(n);
      // One and two carry their own words rather than a digit, exactly as a
      // plain counted noun does: «زجاجة/ساعة»، «زجاجتان/ساعة».
      //
      // Above that the noun takes the plural for three to ten and the bare
      // singular otherwise — never the accusative «12 قميصًا/ساعة». The
      // accusative tanwīn marks a تمييز, and the noun over a rate's slash is not
      // one: it is «قميص في الساعة», written short.
      if (num === 1) return `${u.singular}/${per}`;
      if (num === 2) return `${u.dual}/${per}`;
      const tail = Number.isInteger(num) ? Math.abs(num) % 100 : -1;
      const word = tail >= 3 && tail <= 10 ? u.plural : u.singular;
      return `${displayNumber(n)} ${word}/${per}`;
    }
    const label = INVARIANT_UNITS[unitId];
    return label ? `${displayNumber(n)} ${label}` : displayNumber(n);
  }
  const id = resolveUnitId(unitId);
  if (!id) throw new Error(`Unknown unit id: ${unitId}`);
  const u = UNITS[id];
  const num = Number(n);
  if (!Number.isFinite(num)) return `${displayNumber(n)} ${u.accSing}`;
  if (Number.isInteger(num)) {
    if (num === 1) return u.one;
    if (num === 2) return grammaticalContext === 'oblique' ? u.dualOblique : u.dual;
    return `${displayNumber(num)} ${formOf(u, num)}`;
  }
  return `${displayNumber(num)} ${u.accSing}`;
}

// ---------------------------------------------------------------------------
// RC2.1-4. Agreement helpers.
//
// The independent review of holdout B found «يومين إضافية»: a dual noun carrying
// a feminine-singular adjective. The cause was renderers appending a fixed
// adjective string next to a counted noun whose form varies with the count, so
// the two agreed only by luck. These helpers derive the correct form instead.
//
// Gender is read off the `one` form already in the table rather than added as a
// new field, so it cannot drift out of step with the noun it describes.
// ---------------------------------------------------------------------------

const isFeminine = u => u.one.endsWith('واحدة');

/**
 * RC2.8-6. Whether a unit's noun is feminine, so a template can agree a VERB
 * with it.
 *
 * «كم قميصًا أُنتجت؟» was published: the verb agreed with nothing in the
 * sentence. The lexicon already knows the gender of every unit — it uses it for
 * adjectives — and the only reason a stem could disagree with its own noun was
 * that the knowledge was not reachable from outside this module.
 */
export function unitIsFeminine(id) {
  const u = UNITS[id];
  if (!u) throw new Error(`UNKNOWN_UNIT_ID: ${id}`);
  return isFeminine(u);
}

/** A past-tense verb agreed with the unit's noun: أُنتج / أُنتجت. */
export function agreeingPastVerb(id, masculine, feminine) {
  return unitIsFeminine(id) ? feminine : masculine;
}

/**
 * An attributive adjective agreeing with a counted noun, e.g.
 * `${u(2,'day','oblique')} ${adj(2,'day','إضافي')}` -> «يومين إضافيين».
 *
 * Arabic agreement for counted things:
 *   1        the noun is singular      -> masculine/feminine singular
 *   2        the noun is dual          -> dual, matching the case of the noun
 *   3..10    a broken plural of a non-human is treated as feminine singular
 *   11+      the noun returns to the accusative singular
 *
 * @param {number} n     the count the noun was rendered for
 * @param {string} unitId
 * @param {string} stem  masculine singular base, e.g. 'إضافي'
 * @param {'nominative'|'oblique'} [ctx] case of the dual, matching the noun
 */
export function agreeingAdjective(n, unitId, stem, ctx = 'oblique') {
  const id = resolveUnitId(unitId);
  if (!id) throw new Error(`Unknown unit id: ${unitId}`);
  const fem = isFeminine(UNITS[id]);
  const num = Number(n);
  if (Number.isInteger(num)) {
    if (num === 1) return fem ? `${stem}ة` : stem;
    if (num === 2) {
      if (ctx === 'nominative') return fem ? `${stem}تان` : `${stem}ان`;
      return fem ? `${stem}تين` : `${stem}ين`;
    }
    const tail = Math.abs(num) % 100;
    if (tail >= 3 && tail <= 10) return `${stem}ة`;
    // RC2.9-6. After a round hundred or thousand the noun is a singular in the
    // genitive — «أربعمئة يوم» — so its adjective is the plain singular too,
    // never the accusative «يومًا إضافيًا» that eleven upwards takes.
    if (tail === 0 && Math.abs(num) >= 100) return fem ? `${stem}ة` : stem;
    if (tail === 1) return fem ? `${stem}ة` : stem;
    if (tail === 2) {
      if (ctx === 'nominative') return fem ? `${stem}تان` : `${stem}ان`;
      return fem ? `${stem}تين` : `${stem}ين`;
    }
  }
  // Eleven to ninety-nine, and any non-integer, take the accusative singular.
  return fem ? `${stem}ة` : `${stem}ًا`;
}

/**
 * The definite singular of a unit («الصندوق»), and the same with «الواحد»
 * agreeing («الصندوق الواحد», «القطعة الواحدة»).
 *
 * RC2.1-4. Prose that names an entity must take the name from this table, which
 * is the single source of truth for what that entity is called. Holdout B
 * shipped a stem that said «علبة» while the formatter rendered «صندوق» for the
 * very same object, because the prose hardcoded a second noun of its own.
 */
export function definiteSingular(unitId) {
  const id = resolveUnitId(unitId);
  if (!id) throw new Error(`Unknown unit id: ${unitId}`);
  return `ال${UNITS[id].singular}`;
}

/** Bare indefinite singular («صندوق»), the form «كل» takes. */
export function singularOf(unitId) {
  const id = resolveUnitId(unitId);
  if (!id) throw new Error(`Unknown unit id: ${unitId}`);
  return UNITS[id].singular;
}

/** Accusative singular («صندوقًا»), the form the tamyiz after «كم» takes. */
export function accusativeSingularOf(unitId) {
  const id = resolveUnitId(unitId);
  if (!id) throw new Error(`Unknown unit id: ${unitId}`);
  return UNITS[id].accSing;
}

export function definitePlural(unitId) {
  const id = resolveUnitId(unitId);
  if (!id) throw new Error(`Unknown unit id: ${unitId}`);
  return `ال${UNITS[id].plural}`;
}

export function theSingleUnit(unitId) {
  const id = resolveUnitId(unitId);
  if (!id) throw new Error(`Unknown unit id: ${unitId}`);
  return `ال${UNITS[id].singular} ${isFeminine(UNITS[id]) ? 'الواحدة' : 'الواحد'}`;
}

/** Bare unit word for a count, without the numeral (used in mid-sentence prose). */
/**
 * Which form a counted noun takes after a number.
 *
 * RC2.9-6. The تمييز agrees with the LAST element of the number, not with its
 * size. Before this, everything from eleven upwards took the accusative
 * singular, so a stem said «400 قميصًا» and «4000 درهمًا» — a form an Arabic
 * teacher marks. After a round hundred or thousand the تمييز is a singular in
 * the GENITIVE, which in this lexicon is the bare `singular` form:
 *
 *   1               مفرد          درهم واحد / درهم
 *   2               مثنى          درهمان
 *   3–10            جمع مجرور     ثلاثة دراهم
 *   11–99           مفرد منصوب    خمسون درهمًا
 *   100, 1000, …    مفرد مجرور    أربعمئة درهم، أربعة آلاف درهم
 *
 * and a compound follows its own last element: «مئة وثلاثة دراهم»,
 * «مئة وعشرون درهمًا», «مئة درهم».
 */
function formOf(u, n) {
  if (!Number.isInteger(n)) return u.accSing;
  const abs = Math.abs(n);
  // The dual and the lone singular belong to the numbers one and two
  // THEMSELVES. RC2.9 let them apply to any number ending in one or two, which
  // published «302 علبتان» — a dual noun after three hundred and two. In a
  // compound the تمييز of the hundred governs: «ثلاثمئة واثنتان» is counted
  // «302 علبة».
  if (abs === 1) return u.singular;
  if (abs === 2) return u.dual;
  const tail = abs % 100;
  if (tail >= 3 && tail <= 10) return u.plural;
  if (tail >= 11 && tail <= 99) return u.accSing;
  // Everything left ends in a round hundred or thousand, or in a one or a two
  // carried by one: a singular in the genitive, which is the bare form.
  return u.singular;
}

export function unitWordFor(n, unitId) {
  const id = resolveUnitId(unitId);
  if (!id) throw new Error(`Unknown unit id: ${unitId}`);
  return formOf(UNITS[id], Number(n));
}

// ---------------------------------------------------------------------------
// Output-side safety net (Section 12-B). The deterministic gate is the grep in
// tools/check-manual-units.mjs; this scans rendered text as a second net.
// ---------------------------------------------------------------------------

const ALL_FORMS = (() => {
  const map = new Map(); // surface form -> {id, kind}
  for (const [id, u] of Object.entries(UNITS)) {
    map.set(u.singular, {id, kind:'singular'});
    map.set(u.dual, {id, kind:'dual'});
    map.set(u.dualOblique, {id, kind:'dual'});
    map.set(u.plural, {id, kind:'plural'});
    map.set(u.accSing, {id, kind:'accSing'});
  }
  return map;
})();

/**
 * Which unit a surface word is a form of, or null.
 *
 * RC2.9.1. A rate's numerator inflects now — «5 زجاجات/ساعة», «20 زجاجة/ساعة» —
 * so «does the stem contain this word?» stopped being a fair test of whether an
 * answer is in the unit the question asked about. What has to match is the
 * UNIT, not the spelling of it, and the lexicon is what knows the difference.
 */
export const unitIdOfWord = word => ALL_FORMS.get(String(word ?? '').trim())?.id ?? null;

/** Every surface form a unit can take, for checking a stem against an option. */
export const surfaceFormsOf = unitId => {
  const u = UNITS[resolveUnitId(unitId)];
  return u ? [u.singular, u.dual, u.dualOblique, u.plural, u.accSing] : [];
};

const NUMBER_UNIT_RE = /(\d+(?:\.\d+)?)\s+([ء-يٰٱً-ْ]+)/g;

/**
 * Finds `<digits> <unit word>` pairs in rendered text and reports the ones whose
 * form does not agree with the count.
 * @returns {{violations: Array<{number:number, word:string, expected:string}>}}
 */
export function checkArabicNumberUnits(text) {
  const violations = [];
  if (!text) return {violations};
  const src = String(text);
  for (const m of src.matchAll(NUMBER_UNIT_RE)) {
    const n = Number(m[1]);
    const word = m[2];
    const form = ALL_FORMS.get(word);
    if (!form) continue; // not a lexicon unit: nothing to judge
    // A compound rate symbol such as `وحدة/ساعة` or `كم/ساعة` is a unit name,
    // not a counted noun, so number agreement does not apply to it.
    const after = src[m.index + m[0].length];
    const beforeWord = src[m.index + m[0].length - word.length - 1];
    if (after === '/' || beforeWord === '/') continue;
    const expectedWord = expectedFormWord(n, form.id);
    // n===1 and n===2 must not carry a numeral at all.
    if (Number.isInteger(n) && (n === 1 || n === 2)) {
      violations.push({number:n, word, expected: formatNumberWithUnit(n, form.id)});
      continue;
    }
    if (word !== expectedWord) {
      violations.push({number:n, word, expected: `${m[1]} ${expectedWord}`});
    }
  }
  return {violations};
}

function expectedFormWord(n, unitId) {
  return formOf(UNITS[unitId], n);
}

export function checkArabicNumberUnitsDeep(strings) {
  const violations = [];
  for (const s of strings) {
    if (typeof s !== 'string') continue;
    violations.push(...checkArabicNumberUnits(s).violations.map(v => ({...v, text: s})));
  }
  return {violations};
}
